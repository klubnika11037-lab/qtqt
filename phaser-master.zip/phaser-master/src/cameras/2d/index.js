/**
 * @author       Richard Davey <rich@phaser.io>
 * @copyright    2013-2026 Phaser Studio Inc.
 * @license      {@link https://opensource.org/licenses/MIT|MIT License}
 */

/**
 * @namespace Phaser.Cameras.Scene2D
 */

module.exports = {

    Camera: require('./Camera'),
    BaseCamera: require('./BaseCamera'),
    CameraManager: require('./CameraManager'),
    Effects: require('./effects'),
    Events: require('./events')

};
