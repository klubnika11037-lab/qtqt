# Context7 Plugin for Antigravity

Context7 solves a common problem with AI coding agents: outdated training data and hallucinated APIs. Instead of relying on stale knowledge, Context7 fetches current documentation directly from source repositories.

## What's Included

- **MCP Server** — Connects Antigravity to Context7's documentation service
- **Skills** — A `context7-mcp` skill with instructions on resolving libraries and fetching documentation

## Authentication

After you install the plugin, open **Agent Settings → Customizations** and click **Authenticate** next to the `context7_context7` server. Sign in to Context7 in your browser to connect.

## Available Tools

### resolve-library-id

Searches for libraries and returns Context7-compatible identifiers.

```
Input: "next.js"
Output: { id: "/vercel/next.js", name: "Next.js", versions: ["v16.2.9", "v15.1.8", ...] }
```

### query-docs

Fetches documentation for a specific library, ranked by relevance to your question.

```
Input: { libraryId: "/vercel/next.js", query: "app router proxy" }
Output: Relevant documentation snippets with code examples
```

## Usage Examples

The plugin works automatically when you ask about libraries:

- "How do I set up authentication in Next.js 16?"
- "Show me React Server Components examples"
- "What's the Prisma syntax for relations?"

## Version Pinning

To get documentation for a specific version, include the version in the library ID:

```
/vercel/next.js/v16.2.9
/supabase/supabase/v2.45.0
```

The `resolve-library-id` tool returns available versions, so you can pick the one that matches your project.
