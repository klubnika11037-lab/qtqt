# Context7 Plugin for GitHub Copilot CLI

Context7 solves a common problem with AI coding agents: outdated training data and hallucinated APIs. Instead of relying on stale knowledge, Context7 fetches current documentation directly from source repositories.

## What's Included

This plugin provides:

- **MCP Server** - Connects Copilot CLI to Context7's documentation service
- **Skills** - Auto-triggers documentation lookups when you ask about libraries
- **Agents** - A dedicated `docs-researcher` agent for focused lookups
- **Commands** - `/context7:docs` for manual documentation queries

## Installation

Add the marketplace and install the plugin:

```bash
copilot plugin marketplace add upstash/context7
copilot plugin install context7@context7-marketplace
```

## Authentication

Authenticate so the hosted Context7 server can identify you and apply your plan's limits. Use one of these methods:

### OAuth

Start an interactive Copilot CLI session. When Context7 asks you to sign in, Copilot CLI opens your browser. Sign in there and return to the terminal.

Non-interactive runs (`copilot -p`) do not open the browser. Sign in from an interactive session first, or use an API key.

### API Key

Create a free API key in the [Context7 dashboard](https://context7.com/dashboard?tab=settings) and export it as an environment variable before launching Copilot CLI:

```bash
# e.g. in ~/.zshrc or ~/.bashrc
export CONTEXT7_API_KEY="your-api-key"
```

Restart Copilot CLI after setting it, then verify the key is being used by checking your usage in the [dashboard](https://context7.com/dashboard).

## Available Tools

### resolve-library-id

Searches for libraries and returns Context7-compatible identifiers.

```
Input: "next.js"
Output: { id: "/vercel/next.js", name: "Next.js", versions: ["v16.2.9", "v15.1.8", ...] }
```

### query-docs

Fetches documentation for a specific library, ranked by relevance to your question.

```
Input: { libraryId: "/vercel/next.js", query: "app router proxy" }
Output: Relevant documentation snippets with code examples
```

## Usage Examples

The plugin works automatically when you ask about libraries:

- "How do I set up authentication in Next.js 16?"
- "Show me React Server Components examples"
- "What's the Prisma syntax for relations?"

For manual lookups, use the command:

```
/context7:docs next.js app router
/context7:docs /vercel/next.js/v16.2.9 proxy
```

Or use the docs-researcher agent when you want to keep your main context clean:

```bash
copilot --agent docs-researcher -p "look up Supabase auth methods"
```

## Version Pinning

To get documentation for a specific version, include the version in the library ID:

```
/vercel/next.js/v16.2.9
/supabase/supabase/v2.45.0
```

The `resolve-library-id` tool returns available versions, so you can pick the one that matches your project.
