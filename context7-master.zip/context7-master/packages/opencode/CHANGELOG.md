# @upstash/context7-opencode

## 0.2.2

### Patch Changes

- 7fe6e09: The rules and skills that `ctx7 setup` and the plugins install are back to their text from before the source code and upgrade guide tools: no `query-code`, `ctx7 code` or `get-upgrade-guide` guidance. The MCP server describes its experimental tools only to users who turned them on.

## 0.2.1

### Patch Changes

- 615e72b: Update the Next.js examples in the tool descriptions, the CLI rule and the bundled skill: the version example is now `/vercel/next.js/v16.2.9`, and the prompts use Next.js 16.

## 0.2.0

### Minor Changes

- 635cfc8: Support OpenCode v2. The plugin now exports a v2 `setup` entrypoint next to the v1 `server` entrypoint, so `opencode plugin add @upstash/context7-opencode` registers the Context7 MCP server and the `context7-mcp` skill on v2 as well.

## 0.1.0

### Minor Changes

- 07580f1: Add `@upstash/context7-opencode`, the official Context7 plugin for OpenCode. Installing it registers the hosted Context7 MCP server and the `context7-mcp` skill. Authentication defaults to OAuth and falls back to `CONTEXT7_API_KEY` or an `apiKey` plugin option.
