import { afterEach, beforeEach, describe, expect, test, vi } from "vitest";
import { Command } from "commander";
import { mkdir, readFile, writeFile, rm, access } from "fs/promises";
import { join } from "path";
import { tmpdir } from "os";
import { readJsonConfig } from "../setup/mcp-writer.js";

const trackEvent = vi.fn();
const mockCheckboxWithHover = vi.fn();
let logOutput: string[];

vi.mock("../utils/tracking.js", () => ({
  trackEvent: (...args: unknown[]) => trackEvent(...args),
}));

vi.mock("../utils/prompts.js", () => ({
  checkboxWithHover: (...args: unknown[]) => mockCheckboxWithHover(...args),
}));

const mockSpinner = {
  start: vi.fn().mockReturnThis(),
  stop: vi.fn().mockReturnThis(),
  succeed: vi.fn().mockReturnThis(),
  fail: vi.fn().mockReturnThis(),
  text: "",
};
vi.mock("ora", () => ({ default: () => mockSpinner }));

import { registerRemoveCommand } from "../commands/remove.js";

let tempDir: string;
let originalCwd: string;

async function exists(path: string): Promise<boolean> {
  try {
    await access(path);
    return true;
  } catch {
    return false;
  }
}

async function runCommand(...args: string[]): Promise<void> {
  const program = new Command();
  program.exitOverride();
  registerRemoveCommand(program);
  await program.parseAsync(["node", "test", ...args]);
}

beforeEach(async () => {
  vi.clearAllMocks();
  logOutput = [];
  // Warnings and errors go to stderr when stdout is not a terminal, as in a test.
  for (const stream of ["log", "error"] as const) {
    vi.spyOn(console, stream).mockImplementation((...args: unknown[]) => {
      logOutput.push(args.join(" "));
    });
  }
  originalCwd = process.cwd();
  tempDir = join(tmpdir(), `ctx7-uninstall-${Date.now()}`);
  await mkdir(tempDir, { recursive: true });
  process.chdir(tempDir);
});

afterEach(async () => {
  process.chdir(originalCwd);
  await rm(tempDir, { recursive: true, force: true });
  vi.restoreAllMocks();
});

describe("remove command", () => {
  test("--t3 removes both provider MCP entries and preserves unrelated servers", async () => {
    await mkdir(join(tempDir, ".codex"), { recursive: true });
    await writeFile(
      join(tempDir, ".mcp.json"),
      JSON.stringify({
        mcpServers: {
          context7: { url: "https://mcp.context7.com/mcp" },
          other: { command: "other" },
        },
      })
    );
    await writeFile(
      join(tempDir, ".codex", "config.toml"),
      '[mcp_servers.context7]\nurl = "https://mcp.context7.com/mcp"\n\n[mcp_servers.other]\ncommand = "other"\n'
    );
    await runCommand("remove", "--t3", "--codex", "--project", "--mcp", "--yes");
    const json = JSON.parse(await readFile(join(tempDir, ".mcp.json"), "utf-8"));
    expect(json.mcpServers.context7).toBeUndefined();
    expect(json.mcpServers.other).toEqual({ command: "other" });
    const toml = await readFile(join(tempDir, ".codex", "config.toml"), "utf-8");
    expect(toml).not.toContain("mcp_servers.context7");
    expect(toml).toContain("mcp_servers.other");
  });

  test("removes only CLI artifacts for cursor project setup", async () => {
    const rulePath = join(tempDir, ".cursor", "rules", "context7.mdc");
    const cliSkillPath = join(tempDir, ".cursor", "skills", "find-docs", "SKILL.md");
    const mcpSkillPath = join(tempDir, ".cursor", "skills", "context7-mcp", "SKILL.md");

    await mkdir(join(tempDir, ".cursor", "rules"), { recursive: true });
    await mkdir(join(tempDir, ".cursor", "skills", "find-docs"), { recursive: true });
    await mkdir(join(tempDir, ".cursor", "skills", "context7-mcp"), { recursive: true });
    await writeFile(rulePath, "cursor rule", "utf-8");
    await writeFile(cliSkillPath, "find docs", "utf-8");
    await writeFile(mcpSkillPath, "mcp skill", "utf-8");

    await runCommand("remove", "--cursor", "--cli", "--project");

    expect(await exists(rulePath)).toBe(false);
    expect(await exists(join(tempDir, ".cursor", "skills", "find-docs"))).toBe(false);
    expect(await exists(mcpSkillPath)).toBe(true);
    expect(trackEvent).toHaveBeenCalledWith("command", { name: "remove" });
    expect(trackEvent).toHaveBeenCalledWith("remove", {
      agents: ["cursor"],
      scope: "project",
      modes: ["cli"],
    });
  });

  test("removing the AGENTS.md section leaves the rest of the file untouched", async () => {
    const agentsPath = join(tempDir, "AGENTS.md");
    const own = "# Project rules\n\n```text\nline a\n\n\nline b\n```\n\n\n## Team notes\n\n";
    const tail = "## Tail section\n";
    await writeFile(
      agentsPath,
      `${own}<!-- context7 -->\nrule body\n<!-- context7 -->\n\n${tail}`,
      "utf-8"
    );

    await runCommand("remove", "--codex", "--cli", "--project");

    // Blank lines inside the fenced block and between the user's own sections
    // are not ours to normalize; only the seam of the removed section is.
    expect(await readFile(agentsPath, "utf-8")).toBe(`${own}${tail}`);
  });

  test("removing a trailing AGENTS.md section keeps the preceding content", async () => {
    const agentsPath = join(tempDir, "AGENTS.md");
    await writeFile(
      agentsPath,
      "# Before\n\nkeep   \n\n<!-- context7 -->\nrule body\n<!-- context7 -->\n",
      "utf-8"
    );

    await runCommand("remove", "--codex", "--cli", "--project");

    expect(await readFile(agentsPath, "utf-8")).toBe("# Before\n\nkeep   \n");
  });

  test("removes the AGENTS.md section from a file with CRLF line endings", async () => {
    const agentsPath = join(tempDir, "AGENTS.md");
    await writeFile(
      agentsPath,
      "# Before\r\n\r\n<!-- context7 -->\r\nrule body\r\n<!-- context7 -->\r\n\r\n# After\r\n",
      "utf-8"
    );

    await runCommand("remove", "--codex", "--cli", "--project");

    expect(await readFile(agentsPath, "utf-8")).toBe("# Before\r\n\r\n# After\r\n");
  });

  test("removes only MCP artifacts for codex project setup", async () => {
    const agentsPath = join(tempDir, "AGENTS.md");
    const tomlPath = join(tempDir, ".codex", "config.toml");
    const mcpSkillPath = join(tempDir, ".agents", "skills", "context7-mcp", "SKILL.md");
    const cliSkillPath = join(tempDir, ".agents", "skills", "find-docs", "SKILL.md");

    await mkdir(join(tempDir, ".codex"), { recursive: true });
    await mkdir(join(tempDir, ".agents", "skills", "context7-mcp"), { recursive: true });
    await mkdir(join(tempDir, ".agents", "skills", "find-docs"), { recursive: true });
    await writeFile(
      agentsPath,
      "# Before\n\n<!-- context7 -->\nrule body\n<!-- context7 -->\n",
      "utf-8"
    );
    await writeFile(
      tomlPath,
      'model = "gpt-5"\n\n[mcp_servers.context7]\nurl = "https://mcp.context7.com/mcp"\n\n[mcp_servers.other]\nurl = "https://other.com"\n',
      "utf-8"
    );
    await writeFile(mcpSkillPath, "mcp skill", "utf-8");
    await writeFile(cliSkillPath, "find docs", "utf-8");

    await runCommand("remove", "--codex", "--mcp", "--project");

    const agentsContent = await readFile(agentsPath, "utf-8");
    const tomlContent = await readFile(tomlPath, "utf-8");

    expect(agentsContent).not.toContain("<!-- context7 -->");
    expect(tomlContent).toContain("[mcp_servers.other]");
    expect(tomlContent).not.toContain("[mcp_servers.context7]");
    expect(await exists(join(tempDir, ".agents", "skills", "context7-mcp"))).toBe(false);
    expect(await exists(cliSkillPath)).toBe(true);
    expect(trackEvent).toHaveBeenCalledWith("remove", {
      agents: ["codex"],
      scope: "project",
      modes: ["mcp"],
    });
  });

  test("supports uninstall alias and --all to remove both setup modes", async () => {
    const agentsPath = join(tempDir, "AGENTS.md");
    const tomlPath = join(tempDir, ".codex", "config.toml");
    const mcpSkillPath = join(tempDir, ".agents", "skills", "context7-mcp", "SKILL.md");
    const cliSkillPath = join(tempDir, ".agents", "skills", "find-docs", "SKILL.md");

    await mkdir(join(tempDir, ".codex"), { recursive: true });
    await mkdir(join(tempDir, ".agents", "skills", "context7-mcp"), { recursive: true });
    await mkdir(join(tempDir, ".agents", "skills", "find-docs"), { recursive: true });
    await writeFile(
      agentsPath,
      "# Before\n\n<!-- context7 -->\nrule body\n<!-- context7 -->\n",
      "utf-8"
    );
    await writeFile(
      tomlPath,
      '[mcp_servers.context7]\nurl = "https://mcp.context7.com/mcp"\n',
      "utf-8"
    );
    await writeFile(mcpSkillPath, "mcp skill", "utf-8");
    await writeFile(cliSkillPath, "find docs", "utf-8");

    await runCommand("uninstall", "--codex", "--all", "--project");

    const agentsContent = await readFile(agentsPath, "utf-8");
    expect(agentsContent).not.toContain("<!-- context7 -->");
    expect(await exists(join(tempDir, ".agents", "skills", "context7-mcp"))).toBe(false);
    expect(await exists(join(tempDir, ".agents", "skills", "find-docs"))).toBe(false);
    expect(await readFile(tomlPath, "utf-8")).not.toContain("[mcp_servers.context7]");
    expect(trackEvent).toHaveBeenCalledWith("remove", {
      agents: ["codex"],
      scope: "project",
      modes: ["mcp", "cli"],
    });
  });

  test("skips mode prompt when only one setup mode exists", async () => {
    const rulePath = join(tempDir, ".cursor", "rules", "context7.mdc");
    const cliSkillPath = join(tempDir, ".cursor", "skills", "find-docs", "SKILL.md");
    const mcpSkillPath = join(tempDir, ".cursor", "skills", "context7-mcp", "SKILL.md");

    await mkdir(join(tempDir, ".cursor", "rules"), { recursive: true });
    await mkdir(join(tempDir, ".cursor", "skills", "find-docs"), { recursive: true });
    await mkdir(join(tempDir, ".cursor", "skills", "context7-mcp"), { recursive: true });
    await writeFile(rulePath, "cursor rule", "utf-8");
    await writeFile(cliSkillPath, "find docs", "utf-8");
    await writeFile(mcpSkillPath, "mcp skill", "utf-8");

    await rm(join(tempDir, ".cursor", "skills", "context7-mcp"), { recursive: true });

    await runCommand("remove", "--cursor", "--project");

    expect(mockCheckboxWithHover).not.toHaveBeenCalled();
    expect(await exists(rulePath)).toBe(false);
    expect(await exists(join(tempDir, ".cursor", "skills", "find-docs"))).toBe(false);
    expect(await exists(mcpSkillPath)).toBe(false);
    expect(trackEvent).toHaveBeenCalledWith("remove", {
      agents: ["cursor"],
      scope: "project",
      modes: ["cli"],
    });
  });

  test("prompts for setup mode when both MCP and CLI artifacts exist", async () => {
    const agentsPath = join(tempDir, "AGENTS.md");
    const tomlPath = join(tempDir, ".codex", "config.toml");
    const mcpSkillPath = join(tempDir, ".agents", "skills", "context7-mcp", "SKILL.md");
    const cliSkillPath = join(tempDir, ".agents", "skills", "find-docs", "SKILL.md");

    await mkdir(join(tempDir, ".codex"), { recursive: true });
    await mkdir(join(tempDir, ".agents", "skills", "context7-mcp"), { recursive: true });
    await mkdir(join(tempDir, ".agents", "skills", "find-docs"), { recursive: true });
    await writeFile(
      agentsPath,
      "# Before\n\n<!-- context7 -->\nrule body\n<!-- context7 -->\n",
      "utf-8"
    );
    await writeFile(
      tomlPath,
      '[mcp_servers.context7]\nurl = "https://mcp.context7.com/mcp"\n',
      "utf-8"
    );
    await writeFile(mcpSkillPath, "mcp skill", "utf-8");
    await writeFile(cliSkillPath, "find docs", "utf-8");
    mockCheckboxWithHover.mockResolvedValueOnce(["cli"]);

    await runCommand("remove", "--codex", "--project");

    expect(mockCheckboxWithHover).toHaveBeenCalledTimes(1);
    expect(mockCheckboxWithHover.mock.calls[0]?.[0]).toMatchObject({
      message: "Which Context7 setup modes do you want to remove?",
    });
    expect(await exists(join(tempDir, ".agents", "skills", "find-docs"))).toBe(false);
    expect(await exists(mcpSkillPath)).toBe(true);
    expect(await readFile(tomlPath, "utf-8")).toContain("[mcp_servers.context7]");
    expect(trackEvent).toHaveBeenCalledWith("remove", {
      agents: ["codex"],
      scope: "project",
      modes: ["cli"],
    });
  });

  test("does not log not found items when other artifacts were removed", async () => {
    const agentsPath = join(tempDir, "AGENTS.md");
    const tomlPath = join(tempDir, ".codex", "config.toml");
    const mcpSkillPath = join(tempDir, ".agents", "skills", "context7-mcp", "SKILL.md");

    await mkdir(join(tempDir, ".codex"), { recursive: true });
    await mkdir(join(tempDir, ".agents", "skills", "context7-mcp"), { recursive: true });
    await writeFile(
      agentsPath,
      "# Before\n\n<!-- context7 -->\nrule body\n<!-- context7 -->\n",
      "utf-8"
    );
    await writeFile(
      tomlPath,
      '[mcp_servers.context7]\nurl = "https://mcp.context7.com/mcp"\n',
      "utf-8"
    );
    await writeFile(mcpSkillPath, "mcp skill", "utf-8");

    await runCommand("remove", "--codex", "--all", "--project");

    expect(logOutput.some((line) => line.includes("MCP config removed"))).toBe(true);
    expect(logOutput.some((line) => line.includes("Rule removed"))).toBe(true);
    expect(logOutput.some((line) => line.includes("Skill context7-mcp removed"))).toBe(true);
    expect(logOutput.some((line) => line.includes("not found"))).toBe(false);
  });

  test("removes only context7 from cursor JSON MCP config", async () => {
    const mcpPath = join(tempDir, ".cursor", "mcp.json");

    await mkdir(join(tempDir, ".cursor"), { recursive: true });
    await writeFile(
      mcpPath,
      JSON.stringify(
        {
          theme: "dark",
          mcpServers: {
            alpha: { url: "https://alpha.com" },
            context7: { url: "https://mcp.context7.com/mcp" },
            omega: { url: "https://omega.com" },
          },
          telemetry: { enabled: true },
        },
        null,
        2
      ),
      "utf-8"
    );

    await runCommand("remove", "--cursor", "--mcp", "--project");

    expect(JSON.parse(await readFile(mcpPath, "utf-8"))).toEqual({
      theme: "dark",
      mcpServers: {
        alpha: { url: "https://alpha.com" },
        omega: { url: "https://omega.com" },
      },
      telemetry: { enabled: true },
    });
  });

  test("removes only context7 from VS Code MCP config", async () => {
    const mcpPath = join(tempDir, ".vscode", "mcp.json");

    await mkdir(join(tempDir, ".vscode"), { recursive: true });
    await writeFile(
      mcpPath,
      JSON.stringify(
        {
          servers: {
            other: { type: "http", url: "https://other.com" },
            context7: { type: "http", url: "https://mcp.context7.com/mcp" },
          },
        },
        null,
        2
      ),
      "utf-8"
    );

    await runCommand("remove", "--vscode", "--mcp", "--project");

    expect(JSON.parse(await readFile(mcpPath, "utf-8"))).toEqual({
      servers: { other: { type: "http", url: "https://other.com" } },
    });
  });

  test("removes only context7 from Devin MCP config", async () => {
    const configPath = join(tempDir, ".devin", "mcp_config.json");

    await mkdir(join(tempDir, ".devin"), { recursive: true });
    await writeFile(
      configPath,
      JSON.stringify(
        {
          mcpServers: {
            context7: { transport: "http", url: "https://mcp.context7.com/mcp" },
            other: { command: "other" },
          },
        },
        null,
        2
      ),
      "utf-8"
    );

    await runCommand("remove", "--devin", "--mcp", "--project");

    expect(JSON.parse(await readFile(configPath, "utf-8"))).toEqual({
      mcpServers: { other: { command: "other" } },
    });
  });

  test("removes Copilot CLI project config from .mcp.json", async () => {
    const configPath = join(tempDir, ".mcp.json");

    await writeFile(
      configPath,
      JSON.stringify(
        {
          mcpServers: {
            other: { type: "http", url: "https://other.com" },
            context7: {
              type: "http",
              url: "https://mcp.context7.com/mcp",
              tools: ["*"],
            },
          },
        },
        null,
        2
      ),
      "utf-8"
    );

    await runCommand("remove", "--copilot", "--mcp", "--project");

    expect(JSON.parse(await readFile(configPath, "utf-8"))).toEqual({
      mcpServers: { other: { type: "http", url: "https://other.com" } },
    });
  });

  test("removes only context7 from opencode JSONC MCP config", async () => {
    const configPath = join(tempDir, "opencode.jsonc");

    await writeFile(
      configPath,
      `{
  // keep this file functional after removing Context7
  "theme": "night",
  "mcp": {
    // first server
    "alpha": { "type": "remote", "url": "https://alpha.com", "enabled": true },
    "context7": { "type": "remote", "url": "https://mcp.context7.com/mcp", "enabled": true },
    "omega": { "type": "remote", "url": "https://omega.com", "enabled": false },
  },
  "telemetry": { "enabled": true }
}
`,
      "utf-8"
    );

    await runCommand("remove", "--opencode", "--mcp", "--project");

    const updated = await readFile(configPath, "utf-8");
    expect(updated).toContain("// keep this file functional after removing Context7");
    expect(updated).toContain("// first server");
    expect(updated).toContain(
      '"omega": { "type": "remote", "url": "https://omega.com", "enabled": false },'
    );
    expect(await readJsonConfig(configPath)).toEqual({
      theme: "night",
      mcp: {
        alpha: { type: "remote", url: "https://alpha.com", enabled: true },
        omega: { type: "remote", url: "https://omega.com", enabled: false },
      },
      telemetry: { enabled: true },
    });
  });

  test("detects and removes context7 from an opencode 2.x mcp.servers map", async () => {
    const configPath = join(tempDir, "opencode.jsonc");

    await writeFile(
      configPath,
      `{
  // keep
  "mcp": {
    "servers": {
      "alpha": { "type": "remote", "url": "https://alpha.com" },
      "context7": { "type": "remote", "url": "https://mcp.context7.com/mcp" },
    },
  },
}
`,
      "utf-8"
    );
    mockCheckboxWithHover.mockResolvedValueOnce(["opencode"]);

    await runCommand("remove", "--mcp", "--project");

    expect(logOutput.some((line) => line.includes("Detected: OpenCode"))).toBe(true);
    expect(await readFile(configPath, "utf-8")).toContain("// keep");
    expect(await readJsonConfig(configPath)).toEqual({
      mcp: { servers: { alpha: { type: "remote", url: "https://alpha.com" } } },
    });
  });

  test("detects only agents with Context7 artifacts, not just agent folders", async () => {
    const rulePath = join(tempDir, ".cursor", "rules", "context7.mdc");
    const cliSkillPath = join(tempDir, ".cursor", "skills", "find-docs", "SKILL.md");

    await mkdir(join(tempDir, ".cursor", "rules"), { recursive: true });
    await mkdir(join(tempDir, ".cursor", "skills", "find-docs"), { recursive: true });
    await mkdir(join(tempDir, ".gemini"), { recursive: true });
    await writeFile(rulePath, "cursor rule", "utf-8");
    await writeFile(cliSkillPath, "find docs", "utf-8");
    mockCheckboxWithHover.mockResolvedValueOnce(["cursor"]);

    await runCommand("remove", "--project");

    expect(logOutput.some((line) => line.includes("Detected: Cursor"))).toBe(true);
    expect(logOutput.some((line) => line.includes("Gemini CLI"))).toBe(false);
    expect(mockCheckboxWithHover.mock.calls[0]?.[0]).toMatchObject({
      message: "Which agents do you want to remove Context7 setup from?",
      choices: [{ name: "Cursor", value: "cursor" }],
    });
  });

  test("does not prompt when no Context7 setup is detected", async () => {
    await mkdir(join(tempDir, ".gemini"), { recursive: true });
    await writeFile(join(tempDir, ".gemini", "settings.json"), "{}", "utf-8");

    await runCommand("remove", "--project");

    expect(mockCheckboxWithHover).not.toHaveBeenCalled();
    expect(logOutput.some((line) => line.includes("No Context7 setup detected"))).toBe(true);
  });
});
