import { DEFAULT_CONTEXT7_BASE_URL, getBaseUrl } from "./api.js";

export function trackEvent(event: string, data?: Record<string, unknown>): void {
  if (process.env.CTX7_TELEMETRY_DISABLED || getBaseUrl() !== DEFAULT_CONTEXT7_BASE_URL) return;
  fetch(`${getBaseUrl()}/api/v2/cli/events`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ event, data }),
    // Fire and forget, but never keep the process alive on a stalled host.
    signal: AbortSignal.timeout(3000),
  }).catch(() => {});
}
